from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
version_file = root / 'VERSION.txt'
if not version_file.exists():
    sys.exit('ERROR: VERSION.txt is missing')
raw = version_file.read_text(encoding='utf-8').strip()
version = re.sub(r'(?i)^Version:\s*', '', raw).strip()
if not re.fullmatch(r'\d+\.\d+\.\d+', version):
    sys.exit('ERROR: malformed VERSION.txt; expected Version: MAJOR.MINOR.PATCH')

gradle_file = root / 'app' / 'build.gradle'
if not gradle_file.exists():
    sys.exit('ERROR: app/build.gradle is missing')
gradle = gradle_file.read_text(encoding='utf-8')
required = [
    "rootProject.file('VERSION.txt')",
    'versionName payAviatorVersion',
    'versionCode payAviatorVersionCode',
    "tasks.register('syncPayAviatorWebAssets', Sync)",
    'assets.srcDirs = [generatedWebAssetsDir.get().asFile]',
    "tasks.named('preBuild').configure",
]
for marker in required:
    if marker not in gradle:
        sys.exit(f'ERROR: missing foundation marker: {marker}')
if re.search(r"versionName\s+['\"]\d", gradle):
    sys.exit('ERROR: hardcoded versionName found')
if re.search(r'versionCode\s+\d+', gradle):
    sys.exit('ERROR: hardcoded versionCode found')

web_assets = [
    'index.html','app.css','app.js','payaviator.css','manifest.webmanifest',
    'payaviator-v126-192.png','payaviator-v126-512.png','payaviator-v126-favicon.png','VERSION.txt'
]
for name in web_assets:
    if not (root / name).exists():
        sys.exit(f'ERROR: required authoritative web source missing: {name}')

html = (root / 'index.html').read_text(encoding='utf-8')
if re.search(r"const VERSION=['\"]\d+\.\d+\.\d+['\"]", html):
    sys.exit('ERROR: hardcoded active VERSION constant found in index.html')
if "AndroidBridge.getAppVersionName" not in html:
    sys.exit('ERROR: index.html is not using installed APK version bridge')

print(f'PayAviator foundation verified: {version}')
