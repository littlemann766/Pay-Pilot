# PayAviator signing security

PayAviator uses its own Android signing identity starting with version 8.0.0.

- Application ID: `com.payaviator.app`
- Key alias: `payaviator`
- GitHub secret: `PAYAVIATOR_KEYSTORE_HEX`
- GitHub secret: `PAYAVIATOR_KEYSTORE_PASSWORD`

The private keystore is NOT stored in this repository.

Keep the original `PayAviator-release.jks` and its password in a secure offline backup.
Losing this key means future APKs cannot update installs signed by this key.
