# Pay-Pilot release numbering

Official start: **8.0.0**

The last digit advances from 0 through 9:
8.0.0, 8.0.1, ... 8.0.9.

After .9, increase the middle digit and reset the last digit:
8.0.9 → 8.1.0
8.1.9 → 8.2.0
8.2.9 → 8.3.0

Android versionCode mapping:
8.0.0 → 80000
8.0.1 → 80001
8.0.9 → 80009
8.1.0 → 80100
