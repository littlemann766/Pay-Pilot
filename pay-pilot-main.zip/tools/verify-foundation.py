from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
version_file = root / 'VERSION.txt'
if not version_file.exists():
    sys.exit('ERROR VERSION.txt is missing')

raw = version_file.read_text(encoding='utf-8').strip()
version = re.sub(r'(?i)^Version:\s*', '', raw).strip()
if not re.fullmatch(r'\d+\.\d+\.\d+', version):
    sys.exit('ERROR malformed VERSION.txt; expected Version: MAJOR.MINOR.PATCH')

gradle_file = root / 'app' / 'build.gradle'
if not gradle_file.exists():
    sys.exit('ERROR app/build.gradle is missing')
gradle = gradle_file.read_text(encoding='utf-8')

required_gradle_markers = [
    "rootProject.file('VERSION.txt')",
    'versionName payPilotVersion',
    'versionCode payPilotVersionCode',
    "tasks.register('syncPayPilotWebAssets'",
    "tasks.named('preBuild').configure",
]
for marker in required_gradle_markers:
    if marker not in gradle:
        sys.exit(f'ERROR missing Gradle foundation marker: {marker}')

if re.search(r"versionName\s+['\"]\d", gradle):
    sys.exit('ERROR hardcoded versionName found; VERSION.txt must be authoritative')
if re.search(r'versionCode\s+\d+', gradle):
    sys.exit('ERROR hardcoded versionCode found; VERSION.txt must be authoritative')

for filename in [
    'index.html', 'app.css', 'app.js', 'mybills.css',
    'manifest.webmanifest', 'VERSION.txt'
]:
    if not (root / filename).exists():
        sys.exit(f'ERROR required web source is missing: {filename}')

print(f'Pay-Pilot foundation verified: {version}')
