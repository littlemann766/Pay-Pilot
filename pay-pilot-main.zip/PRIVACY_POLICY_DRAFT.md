# Pay-Pilot Privacy Policy — Production Draft

**Last updated:** September 13, 2026

Pay-Pilot is a personal budgeting and financial-management application.

## Information you enter
Pay-Pilot can store information you choose to enter, including bills, due dates, payments, income, spending, refunds, work hours, categories, reminders, cash-on-hand values, savings goals, and budgeting preferences.

## Connected financial accounts and Plaid
If you choose to connect a financial account, Pay-Pilot uses Plaid to access only the financial information you authorize during Plaid Link. Depending on the products enabled, this can include account names and types, balances, and transaction history. Bank login credentials are handled by Plaid and/or your financial institution and are not stored by Pay-Pilot.

Plaid access tokens are stored only on the Pay-Pilot backend and are not embedded in the Android application. Pay-Pilot may cache synced account and transaction data on your device so the app can display budgeting and spending information.

## How connected financial data is used
Connected financial data is used to provide features you request, including Available Now, Safe to Spend, transaction tracking, spending summaries, and budgeting projections. Pay-Pilot does not sell connected financial data or use it for advertising.

## Physical cash and bank savings
Physical cash tracked in Pay-Pilot is entered manually and is separate from connected bank savings. Savings, CD, and money-market accounts are protected from spendable totals by default.

## Backups and exports
Backup and export files are created only when you choose to save them. You choose where exported files are stored. Exported files are not automatically deleted when you disconnect a bank or delete app data.

## Notifications
Pay-Pilot can schedule local bill and reminder notifications.

## Data security
Network requests to the Pay-Pilot backend and Plaid use HTTPS. Plaid secrets and access tokens remain server-side. Local application data is stored in the app's private storage.

## Disconnecting accounts and deleting bank data
You can disconnect a bank from Connected Accounts. Pay-Pilot calls Plaid's Item removal flow and removes the associated cached account information. You can also use **Banking & Privacy → Disconnect all & delete bank data** to remove all Pay-Pilot Plaid Items and clear locally cached bank account and transaction data. This does not delete accounts held at your financial institution.

## Plaid
Plaid has its own privacy practices and controls. Users can review Plaid's End User Privacy Policy and manage Plaid connections through Plaid Portal at my.plaid.com.

## Contact
**Required before public launch:** replace this section with a real support email or website controlled by the developer, and publish this policy at a stable public URL used in the Play Store and Plaid Dashboard.
