# Pay-Pilot Terms of Service — Production Draft

**Last updated:** September 13, 2026

Pay-Pilot is a personal budgeting and financial-management tool. It does not hold or move money, provide banking services, or provide professional financial, investment, tax, or legal advice.

Connected financial information can be delayed, incomplete, or temporarily unavailable. Users remain responsible for verifying balances, transactions, due dates, and payments with their financial institutions before making financial decisions.

If you connect an account, you authorize Pay-Pilot and Plaid to access the data scopes presented during Plaid Link for the features you request. You may revoke access by disconnecting an institution in Pay-Pilot, through your financial institution where supported, or through Plaid Portal.

Pay-Pilot may change as features are improved. Material changes affecting connected financial data should be reflected in the Privacy Policy and consent disclosures before release.

**Required before public launch:** add a real support contact and public Terms URL.
