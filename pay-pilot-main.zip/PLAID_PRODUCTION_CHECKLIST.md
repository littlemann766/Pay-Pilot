# Pay-Pilot Plaid Production Checklist

App-side items included in 9.8.9:

- Banking & Privacy screen explaining requested data and its purpose.
- Clear statement that bank credentials are not stored by Pay-Pilot.
- Bank savings kept separate/protected from spendable cash.
- Connected Accounts control for individual bank disconnection.
- Backend disconnection calls Plaid `/item/remove`.
- “Disconnect all & delete bank data” revokes all Pay-Pilot Plaid Items and clears cached bank data.
- Links to Plaid End User Privacy information and Plaid Portal.
- Production-draft Privacy Policy and Terms of Service.
- Android Back closes Pay-Pilot overlays/dialogs before exiting.
- Smart Money Tips updated for banking, cash, Safe to Spend, projection, and debt tools.

Plaid Dashboard / business items that cannot be completed only by app code:

1. Add a real company/app support email or support website.
2. Publish the Pay-Pilot Privacy Policy at a stable public HTTPS URL and enter it in app/store/Plaid profiles where requested.
3. Publish Terms of Service at a stable public HTTPS URL.
4. Complete Plaid application display information, company information, organization/app name, logo, and website.
5. Complete Plaid's Security Questionnaire when required for full Production/OAuth institution access.
6. Keep the approved Plaid products limited to what Pay-Pilot uses: Transactions + Balance unless the use case changes.
7. In Plaid Link customization, select the Financial Management / personal budgeting use case and complete Data Transparency Messaging for US/Canada Production.
8. Confirm the production redirect URI and Hosted Link settings match the Railway deployment and are allowlisted in Plaid.
9. Configure a production webhook URL and handle Item errors / pending disconnect events before broad public launch.
10. Replace Sandbox credentials with Production credentials only after Plaid approval, and keep secrets only in Railway environment variables.
11. Verify Play Store Data Safety disclosures match the final connected-banking behavior.

Do not request Auth, Identity, Income, Assets, Liabilities, Investments, or payment products unless Pay-Pilot actually adds a feature that needs them.
