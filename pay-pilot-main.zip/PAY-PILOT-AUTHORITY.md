# Pay-Pilot Foundation Authority

Version: 9.6.8

This build is the foundation for future Pay-Pilot work. New changes must extend this behavior instead of replacing it with older UI fragments or duplicate logic.

## Foundation rules

- `Pay-Pilot-main.zip` is the canonical GitHub source package.
- Keep the existing Android application id/signing path so upgrades install over prior versions.
- Do not change the Railway/Plaid backend unless a banking API change truly requires it.
- Android Back closes the top-most menu/dialog first and returns to Home only when no menu is open.
- Home gauge is the authoritative money summary.
- The gauge header shows `Pay-Pilot Gauge` and the active view/institution name.
- Gauge dots are prominent and appear only when there is more than one gauge page.
- Extra gauge pages exist only for connected institutions with included spendable accounts. Cash is never duplicated as a full swipe page.
- Savings accounts are protected by default and are not included in Available Now unless explicitly changed by the user.
- The Savings metric must remain readable and clickable.
- Advanced money details are collapsed by default, user-toggleable, and expose technical balance/account math without crowding the easy gauge view.
- The mini Cash Gauge appears only when cash exists and shows spendable cash, protected cash, and total cash in a compact bar-style summary.
- Monthly Income reflects checks received so far in the viewed month.
- Budget uses received income plus added funds/refunds as the working amount.
- Home budget-used / budget-left summary opens Monthly Budget & Limits.
- Budget menu buttons must always open their corresponding tools.
- `Monthly Budget & Limits` opens the budget editor.
- `Paycheck Planner` opens the paycheck planner and gives a useful empty state if no schedule exists.
- `+ Add Spending` opens the spending/budget entry flow and focuses the description field.
- No visible button may be decorative or dead.
- Avoid duplicate renderers for the same feature. New fixes should update the authoritative surface instead of layering competing UI.


## Version + asset authority (locked foundation)

- `VERSION.txt` is the only Pay-Pilot version number edited manually.
- Gradle derives `versionName` and `versionCode` from it.
- Android displays the installed APK version through the native bridge.
- Browser builds read the same `VERSION.txt`.
- Root web files are authoritative; Gradle copies them into `app/src/main/assets` before every build.
- Never manually maintain a second app version in Gradle or either `index.html`.
- A missing/malformed `VERSION.txt` must fail the build.
- App-only version changes do not require Railway/Plaid backend changes unless the API itself changes.

## 9.6.4 clean-foundation lock

- Cash is represented by the mini Cash Gauge only; it is not duplicated as a swipe page.
- The swipe gauge contains All Spendable plus connected institutions that have included spendable accounts.
- Advanced money details are compact when collapsed and preserve their open/closed state.
- Monthly Budget & Limits and Paycheck Planner must open from the Budget tab even if an older event layer exists.
- Saving the monthly budget validates only the monthly budget amount; hidden spending/date fields never block it.
- Add Spending auto-fills a valid date for the viewed month and gives field-specific validation.
- Home budget-used / budget-left opens Monthly Budget & Limits.
- Budget tools include concise descriptions so their purpose is visible.
- Home and major screens reserve bottom space for the fixed navigation.
- The gauge metrics must remain readable at narrow Android widths.


## 9.6.5 foundation corrections
- Gauge summary columns must never overlap on phone widths.
- Gauge pager dots are the primary indication that more institution gauges exist.
- Cash remains a mini gauge only and is not duplicated as a full swipe page.
- Advanced money details are collapsed by default into one compact row.
- Monthly Budget & Limits opens/saves independently from spending-entry validation.
- Paycheck Planner and Home Add Spending must bypass legacy click layers and open reliably.
- Budget landing cards are compact, descriptive, and tappable.


## 9.6.6 foundation corrections
- One outer border around the main Pay-Pilot gauge; nested gauge frame removed.
- Savings metric opens Savings & Cash reliably.
- Advanced money details is a compact disclosure row and expands/collapses reliably.
- Mini Cash Gauge remains with the main gauge and is not duplicated as a swipe page.
- Budget landing screen uses the original single-label centered cards; duplicated titles/descriptions are removed.
- Monthly Budget & Limits and Paycheck Planner retain direct working routes.


## 9.6.8 approved visual foundation
- The approved mockup is the visual authority for Home: clean dark-blue surface, no stacked inner gauge frames, centered Pay-Pilot Gauge header, active institution name, prominent swipe dots, large semicircle gauge, digital Safe to Spend readout, and three clean summary metrics.
- Main gauge swipe pages are All Spendable plus one page per institution with included spendable accounts. Cash is represented only by the mini Cash Gauge.
- Swipe dots render only when more than one main gauge page exists.
- Savings is a real clickable metric and opens Savings & Cash.
- Advanced Money Details is one compact disclosure row; expanded technical data contains balances, pending debits, included account count, protected savings, cushion, formula, connected accounts, and bank sync.
- The mini Cash Gauge sits directly below the main gauge when cash exists and remains visually secondary.
- Budget landing returns to the original single-label centered-button layout. No duplicate titles or descriptions may be injected.
- Monthly Budget & Limits and Paycheck Planner must use direct authoritative routes.
- Add Spending must auto-fill the viewed-month date before legacy validation runs.
- Future work must modify this 9.6.8 authority instead of adding a competing gauge/budget renderer.
