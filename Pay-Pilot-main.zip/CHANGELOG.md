# Pay-Pilot Changelog
Historical release/fix notes consolidated from the former individual FIXES/BUILD_FIX files. App/runtime code is unchanged.

---

## BUILD_FIX_9.2.10.txt

Pay-Pilot 9.2.10 GitHub Actions build fix

- VERSION.txt now uses the exact `Version: 9.2.10` format expected by build-pay-pilot.yml.
- app/build.gradle now reports versionName 9.2.10 and versionCode 90210.
- Current 9.2.9/90209 runtime build metadata blocks were aligned to 9.2.10/90210.
- The themed popup and tap-through fixes from 9.2.10 are preserved.

---

## FIXES_9.2.10.txt

Pay-Pilot 9.2.10 fixes

- Replaced the white Android/browser-style Plaid status/error popup with a Pay-Pilot themed popup.
- Popup now uses the app's navy/blue background, cyan border, white text, rounded corners, and themed OK button.
- "Opening secure bank connection…" now appears as a themed loading notice and dismisses automatically.
- Plaid errors remain visible until OK is tapped.
- Added a short release guard to stop the same tap from closing the popup and activating a control underneath.
- Applied the same bank popup change to both the web source and Android bundled asset copy.

---

## FIXES_9.2.9.txt

Pay-Pilot 9.2.9 (Build 90209)

Changes in this build:
- Android app now loads bundled web assets from a secure HTTPS-like app origin instead of file://.
- This removes the file:// origin that prevented Plaid Link's secure web script from loading correctly.
- WebView now allows cookies needed by secure bank-link flows while still keeping external top-level web navigation outside the trusted app page.
- Connected Accounts controls now activate on a completed click/tap rather than pointer-down.
- Close, account expand/collapse, include/exclude, disconnect, Settings Connected Accounts, and Available Now routing no longer fire the instant a finger touches the screen.
- This prevents the modal from disappearing before the finger is released, which was causing taps to pass through and activate controls underneath.
- Added mobile touch behavior hardening for Connected Accounts buttons.

Files changed:
- app/src/main/java/com/paypilot/app/MainActivity.java
- app/src/main/assets/index.html
- index.html
- app/build.gradle
- VERSION.txt

---

## FIXES_9.3.2.txt

Pay-Pilot 9.3.2

- Fixed themed error popup OK button not closing in the Android APK.
- Applied the fix to BOTH the root web source and app/src/main/assets/index.html (the APK actually loads the asset copy).
- OK now dismisses on pointer/touch press before global tap guards can intercept it.
- Added a separate short transparent release shield after dismissal to prevent tap-through without keeping the popup itself stuck.
- Bumped Android versionName/versionCode and VERSION.txt to 9.3.2.

---

## FIXES_9.4.0.txt

Pay-Pilot 9.4.0 — banking + popup reliability rebuild

1. Fixed themed popup OK button
   - The popup overlay itself was stopping pointer events during capture before the OK button could receive them.
   - Overlay interception now happens in the bubble phase, so OK closes immediately.
   - Tap-through shield remains after dismissal.

2. Rebuilt Android Plaid launch flow
   - The app no longer depends on injecting Plaid's web JavaScript into the main Pay-Pilot WebView.
   - Preferred path: Hosted Link URL from the backend, opened outside the main WebView and returned with paypilot://plaid-complete.
   - Compatibility path: dedicated native PlaidLinkActivity using Plaid's WebView redirect protocol when the current backend only returns link_token.
   - Connected/exit/error results return safely to Pay-Pilot and the account list refreshes.

3. Backend Hosted Link support
   - /api/plaid/create-link-token now requests Hosted Link and returns hosted_link_url.
   - Pending Link tokens are associated with the Pay-Pilot local user id.
   - /api/plaid/hosted-status/:userId retrieves the completed public token using /link/token/get, exchanges it, and stores the Item.
   - Existing account, transaction, disconnect, and token-exchange endpoints remain supported.

4. Android callback support
   - Added paypilot://plaid-complete deep-link handling.
   - Added PlaidLinkActivity to isolate bank linking from the main app WebView.

5. Version
   - versionName 9.4.0
   - versionCode 90400
   - VERSION.txt = Version: 9.4.0

Important deployment note:
The APK compatibility path works with the current create-link-token backend response. For the preferred Hosted Link path, deploy the included backend/server.js to the Railway backend used by Pay-Pilot.

---

## FIXES_9.4.1.txt

Pay-Pilot 9.4.1 — Plaid Hosted Link completion fix

- Uses Plaid Hosted Link as the Android bank-connection path.
- Removes the unreliable in-process Plaid WebView fallback on Android.
- Fixes backend /link/token/get parsing: Hosted Link results live under link_sessions[].results.item_add_results.
- Exchanges and stores every successful public token returned by Hosted Link.
- Adds app-resume completion polling so returning from the browser finishes the connection even if the custom URI callback is not delivered.
- Keeps the custom paypilot://plaid-complete callback as an additional completion signal.
- Adds backend health/version details for easier diagnosis.
- Version: 9.4.1 (90401).

IMPORTANT: The backend/server.js in this package must be deployed to the Railway Pay-Pilot backend. The APK cannot repair an older deployed backend by itself.

---

## FIXES_9.4.1_CONNECTIVITY.md

# Pay-Pilot 9.4.1 connectivity repair

- Adds a bank-service health check before Plaid starts.
- Gives a clear backend deployment message instead of the generic browser “Failed to fetch”.
- Adds a 15-second API timeout so the UI cannot hang indefinitely.
- Keeps Hosted Link as the Android bank-link flow.
- Resets the Backup & App panel scroll position and adds correct top spacing so the first section is not hidden under the header.
- Keeps the app version at 9.4.1 while this connection is being validated end-to-end.

---

## FIXES_9.4.2.txt

Pay-Pilot 9.4.2
- Adds Android handlers for Plaid Hosted Link completion and OAuth/app-to-app return.
- Keeps Pay-Pilot versioning inside the app while repository ZIP name stays stable.

---

## FIXES_9.4.2_RUNTIME.txt

Pay-Pilot 9.4.2 runtime correction
- Corrected all active app UI/runtime version constants from 9.4.1 to 9.4.2.
- Android versionName remains 9.4.2 and versionCode 90402.
- Preserves Hosted Link return handlers and Railway API URL.

---

## FIXES_9.4.3.txt

Pay-Pilot 9.4.3
- Android bank API now uses a native HTTPS bridge to Railway, bypassing WebView fetch/CORS failures.
- Android Back closes Pay-Pilot menus, dialogs, Connected Accounts, settings, tips, and themed notices before exiting.
- Backup & App/settings first content no longer slides under the header.

---

## FIXES_9.4.4.txt

Pay-Pilot 9.4.4
- Plaid Hosted Link backend request now sends exact raw JSON, preserving required redirect fields.
- Loading notice closes before Hosted Link opens or an error notice is shown.
- Existing Android Back/menu fixes retained.

---

## FIXES_9.4.5.txt

Pay-Pilot 9.4.5

- Fix Hosted Link completion by reading Plaid /link/token/get with the raw REST API.
- Correctly parse results.item_add_results and exchange each public_token.
- Distinguish pending, success, exit, and Plaid errors.
- Align app/backend version reporting at 9.4.5.
- Preserve the working Hosted Link launch and Android return flow.

---

## FIXES_9.4.6.txt

Pay-Pilot 9.4.7

- Fix connected-bank save failure on older Railway PostgreSQL databases.
- Backend now automatically adds the missing `plaid_items.user_id` column at startup.
- Verifies all columns used by Plaid item storage without deleting existing data.
- Keeps the working Plaid Hosted Link launch and return flow unchanged.
- Aligns app/backend version reporting at 9.4.7.

---

## FIXES_9.4.7.txt

Pay-Pilot 9.4.7

- Keeps the working Plaid connection flow unchanged.
- Available Now defaults to checking/cash accounts only.
- Savings is protected/excluded by default but can be included manually.
- Credit cards and loans are treated as debt and excluded from Available Now by default.
- Connected Accounts continues to allow per-account include/exclude choices.
- Gauge scale automatically expands for larger Safe to Spend values unless a custom scale is locked.
- App/backend version aligned at 9.4.7.

---

## FIXES_9.4.8.txt

Pay-Pilot 9.4.8

- Counts paycheck occurrences dated today in Monthly Income using the occurrence-specific paycheck amount.
- Uses one canonical included-account balance for Connected Accounts, Home, Cushion, and Safe to Spend.
- Prevents stale all-account balances from resurfacing after cushion/account changes.
- Refreshes Cushion preview from the current included bank balance every time it opens or changes.
- Auto-scales the gauge face and its visible marker labels when the configured scale is not locked/custom.
- Keeps the working Plaid connection and account inclusion rules unchanged.

---

## FIXES_9.4.9.txt

Pay-Pilot 9.4.9

- Android phone Back now closes the active Pay-Pilot popup/menu/dialog/settings surface first.
- Back works through both a Java native fallback and the web UI handler, so later modules cannot disable it.
- Secondary tabs return Home before Android exits the app.
- Canonical connected-account Available Now is reasserted if legacy modules redraw stale totals.
- Working Plaid connection flow remains unchanged.

---

## FIXES_9.5.0.txt

Pay-Pilot 9.5.0
- Savings tile is now a button with connected-bank savings breakdown.
- Added protected cash saved aside and spendable cash on hand.
- Spendable cash adds to Available Now; protected cash adds to Savings.
- Disabled legacy all-account balance writer that could reintroduce stale totals.
- Android Back closes the Savings & Cash sheet.

---

## FIXES_9.5.1.txt

Pay-Pilot 9.5.1
- Savings tile opens Savings & Cash reliably using delegated touch/click handlers.
- Savings total = unique connected savings accounts + protected cash saved aside.
- Savings & Cash lists connected savings accounts and supports protected/spendable cash.
- Android Back closes Savings & Cash.

---

## FIXES_9.5.3.txt

Pay-Pilot 9.5.4

- Version/build metadata aligned across Android and runtime assets.
- Paired backend package cleaned to one authoritative deployment guide.
- Existing 9.5.2 finance-source-of-truth rules preserved.

---

## FIXES_9.6.7.txt

Pay-Pilot 9.6.7
- Rebuilt Home Pay-Pilot Gauge to match the approved visual blueprint.
- Removed stacked inner gauge borders and preserved one clean visual hierarchy.
- Swipe pages are All Spendable + connected institutions only; Cash is no longer duplicated as a full gauge page.
- Prominent swipe dots appear only when more than one gauge exists.
- Savings metric is a real button that opens Savings & Cash.
- Advanced Money Details is a compact disclosure row with technical balance/account diagnostics.
- Mini Cash Gauge remains directly below the main gauge when cash exists.
- Budget landing restored to the original single-label centered-button look; duplicate labels removed.
- Monthly Budget & Limits and Paycheck Planner receive authoritative click routing.
- Budget spending date auto-fills before validation so Add Spending no longer throws a missing-date error.
- VERSION.txt remains the only app-version source for Android builds.

---

## FIXES_9.6.8.txt

Pay-Pilot 9.6.8
- Savings and Cash are now separate UI concepts.
- Savings button opens bank savings only.
- Cash Gauge shows spendable physical cash only; savings is excluded.
- Cash Gauge opens its own Cash editor.
- Advanced Money Details uses a stable capture handler to prevent legacy listener flicker and opens/collapses reliably.
- Reduced unnecessary borders on Savings and Advanced surfaces.
- No backend changes required.

---

## FIXES_9.7.0.txt

Pay-Pilot 9.7.0
- Savings dialog is independently scrollable in Android WebView.
- Bank Savings is separated from physical saved cash.
- Cash editor now has separate Spendable Cash and Saved Cash values.
- Cash Gauge shows spendable, saved, and total physical cash consistently.
- Removed duplicate legacy Advanced Money panel; only one disclosure may render.
- Savings tile reports connected bank savings only.

---

## FIXES_9.7.1.txt

Pay-Pilot 9.7.1

- Removed backdrop blur from Android/mobile dialogs to reduce menu lag.
- Disabled unnecessary menu/dialog transitions and animations on mobile.
- Kept dialog scrolling native and responsive.
- Preserved 9.7.0 Savings scrolling, cash classification, and advanced-money dedupe fixes.
- No backend changes required.

---

## FIXES_9.7.2.txt

Pay-Pilot 9.7.2

- Removed obsolete recent gauge/menu patches that were still polling and observing the Home gauge.
- Removed the 9.7.1 MutationObserver/interval loop that caused Cash Gauge flicker and menu lag.
- Savings tile now opens one authoritative, scrollable bank-savings sheet.
- Cash Gauge now opens a dedicated editor with Spendable Cash and Saved Cash.
- Cash changes redraw once after Save instead of continuously.
- Kept the 9.6.7 gauge foundation and Budget tool wiring as the active UI foundation.

---

## FIXES_9.7.3.txt

Pay-Pilot 9.7.3

Gauge number correction:
- All Spendable gauge again uses the configured Pay-Pilot scale markers instead of automatic quarter values.
- Default labels are $0, $50, $100, $250, and $500.
- Custom scale values set in Edit Cushion / Advanced scale remain respected.
- Gauge color breakpoints now line up with those same configured dollar markers.
- Institution gauges continue using an automatic readable scale appropriate to that institution balance.

---

## FIXES_9.7.4.txt

Pay-Pilot 9.7.4
- Stops unchanged Home gauge redraws and removes the 1.2-second gauge polling loop.
- Uses sane gauge markers so corrupted thresholds cannot show values such as $500 and $501 side-by-side.
- Stabilizes the mini Cash Gauge to prevent Android WebView flicker.
- Restores Bank transaction history on Spending from the existing Plaid transactions endpoint.
- Sync remains read-only and bank transactions are not double-counted against Available Now.

---

## FIXES_9.7.9.txt

Pay-Pilot 9.7.9
- Rolled the app source back to the stable 9.6.8 foundation.
- Keeps the 9.6.8 working gauge, Savings/Cash separation, Advanced Money handler, and existing menu behavior.
- No 9.7.x gauge renderer/redraw experiments are included.
- Version number advanced to 9.7.9 only so Android can install this as an update over newer test builds.
- No backend changes required.

---

## FIXES_9.8.0.txt

Pay-Pilot 9.8.0

Foundation: Pay-Pilot 9.7.3 behavior restored.

Only intended visual change:
- Gauge scale numbers remain visible but are drawn outside the colored gauge arc.
- The 9.7.3 gauge values, scale logic, interactions, Savings/Cash behavior, and Home calculations are otherwise unchanged.
- Later 9.7.4+ gauge/runtime experiments are not included in this foundation.

---

## FIXES_9.8.1.txt

Pay-Pilot 9.8.1

- Makes the 9.7.3-style swipe gauge the single authoritative Home gauge renderer.
- Prevents the older round cockpit gauge renderer from overwriting the working gauge after taps, inputs, view changes, or refresh events.
- Keeps gauge scale labels outside the colored arc.
- Adds a subtle aircraft-instrument bezel to the working semicircle gauge without changing its paging, data, savings, or advanced-money behavior.
- No backend changes.

---

## FIXES_9.8.2.txt

Pay-Pilot 9.8.2

- Available Now now follows checks/monthly budget when no live production bank connection is active.
- Once Plaid reports production mode and included spendable accounts exist, real bank available balances become authoritative.
- Safe to Spend remains Available Now minus Cushion.
- Bank sync now refreshes both real account balances and bank transactions from the existing Railway backend.
- Synced transactions are written to both current and legacy transaction stores so Spending can display bank history.
- Cash remains separate in the Cash Gauge and is not silently added to Available Now.
- No backend source-code changes required; live banking requires the existing Railway backend to run with Plaid production credentials/environment.

---

## FIXES_9.8.4.txt

Pay-Pilot 9.8.4
- Replaces the Safe-to-Spend semicircle with a true round aviation-style gauge.
- Replaces the Cash Gauge bar/semicircle with a matching true round gauge.
- Gauge needle, tick marks, scale labels, and color bands use the same maximum.
- Cash Gauge correctly reads full-scale when spendable cash equals total cash.
- Keeps the existing Pay-Pilot money logic, Plaid integration, swipe pages, and controls intact.

---

## FIXES_9.8.5.txt

Pay-Pilot 9.8.5

- Locks Monthly Income to checks actually received only; added funds/refunds no longer leak into the Monthly Income card.
- Replaces the old full-month double-counting snapshot with Available Now + future checks - remaining unpaid bills.
- Separates funds/refunds from everyday spending in the snapshot.
- Adds Manage Cash: add spendable cash, use/remove cash, move to saved cash, and move saved cash back to spendable.
- Cash spending can be recorded into Spending history as a cash transaction.
- Removes the whole-body gauge MutationObserver from the 9.8.4 round-gauge upgrade and uses event-driven repainting to reduce flicker/lag.
- Keeps the new round aviation gauges and existing Plaid backend unchanged.

---

## FIXES_9.8.7.txt

Pay-Pilot 9.8.7

- Savings and physical cash are separated again. The Savings tile/modal now shows connected bank savings only.
- Removed Connected accounts and Sync bank data buttons from Advanced Money Details; the passive last-sync status remains.
- Cash Gauge reduced to a compact secondary instrument (180px dial).
- Cash Gauge upgrade is explicitly scheduled after each gauge render to prevent the temporary blank/non-gauge state.
- Manage Cash hides the four action choices while an action form is open, then restores them on Cancel/Save.
- Monthly Snapshot now uses the same authoritative Available Now value as the Home gauge, preventing $80.70 on Home vs $58.58 in Snapshot.
- Monthly Income remains checks-only.
- Root index.html and Android app/src/main/assets/index.html are identical.

---

## FIXES_9.8.8.txt

Pay-Pilot 9.8.8

- Cash saved aside now opens physical Manage Cash only, never connected bank savings.
- Retired the legacy direct-edit cash modal so it cannot show through the new cash manager.
- Unified sandbox/check-mode Available Now math across Home and Monthly Snapshot.
- Monthly Snapshot now calculates future scheduled checks from tomorrow through month end.
- Manage Cash note examples now match the selected action.
- Empty Payoff Gauge is hidden until at least one debt balance exists.
- Root index.html and Android packaged asset are synchronized byte-for-byte.

---

## FIXES_9.8.9.txt

Pay-Pilot 9.8.9

- Added Banking & Privacy / Plaid transparency screen.
- Added real server-side disconnect behavior using Plaid item removal.
- Added Disconnect All & Delete Bank Data endpoint/control.
- Added production-draft privacy policy and terms.
- Added Plaid production checklist for dashboard-only requirements.
- Updated Smart Money Tips for live banking, cash vs savings, Safe to Spend, projections and debt.
- Unified Android Back handling for Pay-Pilot overlays, dialogs, settings sheets and secondary tabs.
- Root and Android asset index files kept identical.


## 9.9.0 — Performance stabilization

- Kept the Pay-Pilot UI, calculations, data model, and features unchanged.
- Reduced aggressive background refresh loops that could make Android WebView appear frozen.
- Paused periodic DOM refresh work while the app is not visible.
- Kept immediate event-driven updates in place for user actions.
