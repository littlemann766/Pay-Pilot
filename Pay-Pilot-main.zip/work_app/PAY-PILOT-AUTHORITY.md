# Pay-Pilot Authority — 9.6.0

This is the authoritative implementation note for the current build. Older FIXES/DEPLOY notes are historical only.

## Home modes
- Easy keeps the clean cockpit gauge and the essential decision: what is safe to spend.
- Advanced uses the same gauge but adds the calculation beneath it: available balance, current balance, pending debits, included account count, protected savings, cushion, formula, bank sync time, and shortcuts to accounts/sync.
- All Spendable is always the first gauge. Institution pages only exist when that institution has included spendable accounts. Cash exists only when cash has been entered.
- Gauge paging uses prominent circular dots only; no 1/4 counter. Dots and swipe hint appear only when multiple pages exist.

## Money rules
- Safe to Spend = Available Now - Cushion.
- Savings and saved-aside cash are protected by default and excluded from Safe to Spend.
- Monthly Income is received paychecks for the viewed month, with bank payroll deposits only as fallback.
- Working monthly budget = received paychecks + funds/refunds.
- Bank transaction history is informational and is not subtracted twice from live balances.

## Clarifications
- Home uses Paid This Month. Paid Bills history is explicitly labeled All-Time Paid.
- Budget Used / Budget Left opens Monthly Budget.
- Monthly Budget & Limits and Paycheck Planner are explicitly wired from the Budget screen.
- Android Back closes the topmost menu/dialog before leaving the active section.
- Backup filename remains Pay-Pilot-backup.json.

## Version
- App version: 9.6.0
- Android versionCode: 90600


## 9.6.1 interaction fixes
- Home + Add Spending opens Monthly Budget and focuses the spending form.
- Budget > Monthly Budget & Limits opens reliably with a direct dialog fallback.
- Budget > Paycheck Planner opens reliably with a direct dialog fallback.
- Advanced money details are collapsed by default and can be expanded/collapsed.
