# Pay-Pilot Authority — 9.5.9

This file is the authoritative implementation note for the current build. Older FIXES/DEPLOY notes are historical only.

## Home gauge
- Main gauge keeps the full cockpit-style circular instrument appearance.
- No `1 / 4` counter. Paging is indicated by dots only.
- Dots and swipe hint appear only when more than one gauge page exists.
- `All Spendable` always exists. Institution pages exist only when that institution has at least one included spendable account with a positive balance. Cash exists only when spendable cash is greater than $0.
- Safe to Spend = Available Now - Cushion. Savings is protected and not included in Safe to Spend.
- Gauge scale expands when needed so the needle never pegs or jumps from an undersized scale.

## Finance
- Monthly Income = paychecks whose pay date has occurred in the viewed month; bank payroll deposits are a fallback when no saved paycheck occurrence is available.
- Working monthly budget = received paychecks + funds/refunds.
- Monthly Snapshot uses the same received-income source as Home. Full-month projection uses all scheduled checks in the viewed month.
- Home `Paid This Month` is distinct from all-time Paid Bills history.
- Bank transaction history is informational and does not subtract a second time from Available Now.

## Navigation and Android Back
- Monthly Budget & Limits and Paycheck Planner must open from Budget.
- Android Back closes the topmost dialog/sheet/menu before leaving a screen.
- Backup filename is `Pay-Pilot-backup.json`.

## Version
- App version: 9.5.9
- Android versionCode: 90509
