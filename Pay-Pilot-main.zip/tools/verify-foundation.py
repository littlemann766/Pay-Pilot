from pathlib import Path
import re,sys
r=Path(__file__).resolve().parents[1]; raw=(r/'VERSION.txt').read_text().strip(); v=re.sub(r'(?i)^Version:\s*','',raw).strip()
if not re.fullmatch(r'\d+\.\d+\.\d+',v):sys.exit('ERROR malformed VERSION.txt')
g=(r/'app/build.gradle').read_text()
if "rootProject.file('VERSION.txt')" not in g:sys.exit('ERROR Gradle not using VERSION.txt')
if re.search(r"versionName\s+['\"]\d",g):sys.exit('ERROR hardcoded versionName')
if re.search(r'versionCode\s+\d+',g):sys.exit('ERROR hardcoded versionCode')
for f in ['index.html','app.css','app.js','mybills.css','manifest.webmanifest','VERSION.txt']:
 a=r/f;b=r/'app/src/main/assets'/f
 if a.exists() and (not b.exists() or a.read_bytes()!=b.read_bytes()):sys.exit('ERROR stale Android asset '+f)
print('Pay-Pilot foundation verified:',v)
