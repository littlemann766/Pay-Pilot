import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { Configuration, PlaidApi, PlaidEnvironments, Products, CountryCode } from 'plaid';
const app=express(); app.use(cors()); app.use(express.json());
const env=process.env.PLAID_ENV||'sandbox';
const config=new Configuration({basePath:PlaidEnvironments[env],baseOptions:{headers:{'PLAID-CLIENT-ID':process.env.PLAID_CLIENT_ID,'PLAID-SECRET':process.env.PLAID_SECRET}}});
const plaid=new PlaidApi(config);
// Demo storage only. Replace with encrypted per-user database storage before production.
const items=new Map();
app.get('/health',(req,res)=>res.json({ok:true,environment:env}));
app.post('/api/plaid/create-link-token',async(req,res)=>{try{const r=await plaid.linkTokenCreate({user:{client_user_id:String(req.body.userId||'paypilot-local-user')},client_name:'Pay-Pilot',products:[Products.Transactions],country_codes:[CountryCode.Us],language:'en'});res.json({link_token:r.data.link_token})}catch(e){res.status(500).json({error:'link_token_failed'})}});
app.post('/api/plaid/exchange-public-token',async(req,res)=>{try{const r=await plaid.itemPublicTokenExchange({public_token:req.body.public_token});items.set(String(req.body.userId||'paypilot-local-user'),r.data.access_token);res.json({connected:true,item_id:r.data.item_id})}catch(e){res.status(500).json({error:'token_exchange_failed'})}});
app.get('/api/plaid/accounts/:userId',async(req,res)=>{try{const token=items.get(req.params.userId);if(!token)return res.status(404).json({error:'not_connected'});const r=await plaid.accountsGet({access_token:token});res.json(r.data)}catch(e){res.status(500).json({error:'accounts_failed'})}});

app.get('/api/plaid/transactions/:userId',async(req,res)=>{try{
  const token=items.get(req.params.userId); if(!token)return res.status(404).json({error:'not_connected'});
  const start_date=req.query.start_date||new Date(Date.now()-180*86400000).toISOString().slice(0,10);
  const end_date=req.query.end_date||new Date().toISOString().slice(0,10);
  const r=await plaid.transactionsGet({access_token:token,start_date,end_date,options:{count:250,offset:0}});
  res.json(r.data);
}catch(e){res.status(500).json({error:'transactions_failed'})}});
app.listen(Number(process.env.PORT||8787),()=>console.log('Pay-Pilot backend listening'));
