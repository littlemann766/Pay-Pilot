# Pay-Pilot Project Notes
Non-runtime project, release, store, privacy, and deployment notes consolidated for a cleaner repository. App/runtime code is unchanged.

---

## PLAY_STORE_LISTING_DRAFT.md

# Pay-Pilot — Store Listing Working Draft

## Name
Pay-Pilot

## Short description
Track bills, income, spending, refunds, reminders, and your monthly budget in one private, local-first app.

## Full description
Pay-Pilot is a straightforward personal budgeting and bill-tracking app designed to keep your everyday money picture easy to understand.

Track recurring and one-time bills, record paychecks and other income, see spending alongside paid bills, add refunds or returned funds, and review your budget by week or month. A calendar helps you see what is due and when, while reminders help keep upcoming payments visible.

Pay-Pilot uses a local-first approach. The current Android release keeps budgeting data on your device and does not require an Internet connection. You can create your own backup file whenever you want and restore it later.

Features include bill tracking, recurring payments, paycheck/income tracking, spending/refunds, budgeting, calendar views, local reminders, optional device-authentication app lock, and user-controlled backup/restore.

Pay-Pilot is a budgeting and organization tool. It is not a bank, lender, payment processor, investment service, or financial adviser.

---

## CONNECTED_ACCOUNTS_PLAN.md

# Pay-Pilot Connected Accounts Foundation

## Product rule
Pay-Pilot remains read-only first. The goal is to turn real account activity into a trustworthy **Safe to Spend** number, not to move money.

## Data flow
Pay-Pilot app → secure Pay-Pilot backend → Plaid → financial institution.

## Build sequence
1. Connected Accounts UI and local account/transaction data contract.
2. Plaid Sandbox backend and Link flow.
3. Import balances and transactions.
4. Reconcile imported transactions with manual Spending/Bills.
5. Detect recurring income and obligations with user confirmation.
6. Feed verified data into the Pay-Pilot Gauge.
7. Add authentication/encrypted storage and production hardening before live users.

---

## PRIVACY_POLICY_DRAFT.md

# Pay-Pilot Privacy Policy — Production Draft

**Last updated:** September 13, 2026

Pay-Pilot is a personal budgeting and financial-management application.

## Information you enter
Pay-Pilot can store information you choose to enter, including bills, due dates, payments, income, spending, refunds, work hours, categories, reminders, cash-on-hand values, savings goals, and budgeting preferences.

## Connected financial accounts and Plaid
If you choose to connect a financial account, Pay-Pilot uses Plaid to access only the financial information you authorize during Plaid Link. Depending on the products enabled, this can include account names and types, balances, and transaction history. Bank login credentials are handled by Plaid and/or your financial institution and are not stored by Pay-Pilot.

Plaid access tokens are stored only on the Pay-Pilot backend and are not embedded in the Android application. Pay-Pilot may cache synced account and transaction data on your device so the app can display budgeting and spending information.

## How connected financial data is used
Connected financial data is used to provide features you request, including Available Now, Safe to Spend, transaction tracking, spending summaries, and budgeting projections. Pay-Pilot does not sell connected financial data or use it for advertising.

## Physical cash and bank savings
Physical cash tracked in Pay-Pilot is entered manually and is separate from connected bank savings. Savings, CD, and money-market accounts are protected from spendable totals by default.

## Backups and exports
Backup and export files are created only when you choose to save them. You choose where exported files are stored. Exported files are not automatically deleted when you disconnect a bank or delete app data.

## Notifications
Pay-Pilot can schedule local bill and reminder notifications.

## Data security
Network requests to the Pay-Pilot backend and Plaid use HTTPS. Plaid secrets and access tokens remain server-side. Local application data is stored in the app's private storage.

## Disconnecting accounts and deleting bank data
You can disconnect a bank from Connected Accounts. Pay-Pilot calls Plaid's Item removal flow and removes the associated cached account information. You can also use **Banking & Privacy → Disconnect all & delete bank data** to remove all Pay-Pilot Plaid Items and clear locally cached bank account and transaction data. This does not delete accounts held at your financial institution.

## Plaid
Plaid has its own privacy practices and controls. Users can review Plaid's End User Privacy Policy and manage Plaid connections through Plaid Portal at my.plaid.com.

## Contact
**Required before public launch:** replace this section with a real support email or website controlled by the developer, and publish this policy at a stable public URL used in the Play Store and Plaid Dashboard.

---

## PUBLIC_RELEASE_CHECKLIST.md

# Pay-Pilot — Public Release Checklist

## Build and Android
- [x] Application ID remains `com.mybills.app`.
- [x] Permanent release signing key retained.
- [x] Target Android 16 / API 36.
- [x] Compile with API 36.
- [x] GitHub Actions creates a signed APK.
- [x] GitHub Actions creates a signed Android App Bundle (`.aab`).
- [ ] Confirm 20.0.149 installs over the existing app without data loss.
- [ ] Confirm fresh install works with no existing data.
- [ ] Test Android 16 behavior.
- [ ] Test Android 13–15 compatibility.

## Functional regression
- [ ] Home dashboard totals are correct.
- [ ] Calendar navigation and bill editing work.
- [ ] Recurring bills work.
- [ ] Paying/editing a bill updates totals correctly.
- [ ] Spending includes paid bills.
- [ ] Refund / Funds reduces net spending.
- [ ] Budget calculations remain correct.
- [ ] Backup export succeeds.
- [ ] Backup restore succeeds on a clean install.
- [ ] Notifications/reminders work.
- [ ] App lock works.
- [ ] Android Back behavior remains correct.
- [ ] App works offline.

## Security/privacy
- [x] No Android INTERNET permission.
- [x] Cleartext traffic disabled.
- [x] Automatic Android backup disabled.
- [x] WebView debugging disabled.
- [x] External web pages cannot run inside the bridged WebView.
- [x] Mixed content and universal file access disabled.
- [ ] Dedicated user-input/XSS review.
- [ ] Decide whether app-level encryption is needed before making any encryption claim.
- [ ] Publish final privacy policy at a stable public URL.
- [ ] Put privacy policy link/text inside the released app.

## Google Play
- [ ] Create/verify Play Developer account.
- [ ] Enroll in Play App Signing.
- [ ] Upload `MyBills.aab` to internal testing first.
- [ ] Complete Data safety accurately.
- [ ] Complete Financial features declaration.
- [ ] Complete content rating.
- [ ] Add support contact and privacy-policy URL.
- [ ] Create store icon, feature graphic, screenshots, short/full description.
- [ ] Run closed testing if required for the developer account.
- [ ] Resolve pre-launch report issues before production.

---

## PLAID_PRODUCTION_CHECKLIST.md

# Pay-Pilot Plaid Production Checklist

App-side items included in 9.8.9:

- Banking & Privacy screen explaining requested data and its purpose.
- Clear statement that bank credentials are not stored by Pay-Pilot.
- Bank savings kept separate/protected from spendable cash.
- Connected Accounts control for individual bank disconnection.
- Backend disconnection calls Plaid `/item/remove`.
- “Disconnect all & delete bank data” revokes all Pay-Pilot Plaid Items and clears cached bank data.
- Links to Plaid End User Privacy information and Plaid Portal.
- Production-draft Privacy Policy and Terms of Service.
- Android Back closes Pay-Pilot overlays/dialogs before exiting.
- Smart Money Tips updated for banking, cash, Safe to Spend, projection, and debt tools.

Plaid Dashboard / business items that cannot be completed only by app code:

1. Add a real company/app support email or support website.
2. Publish the Pay-Pilot Privacy Policy at a stable public HTTPS URL and enter it in app/store/Plaid profiles where requested.
3. Publish Terms of Service at a stable public HTTPS URL.
4. Complete Plaid application display information, company information, organization/app name, logo, and website.
5. Complete Plaid's Security Questionnaire when required for full Production/OAuth institution access.
6. Keep the approved Plaid products limited to what Pay-Pilot uses: Transactions + Balance unless the use case changes.
7. In Plaid Link customization, select the Financial Management / personal budgeting use case and complete Data Transparency Messaging for US/Canada Production.
8. Confirm the production redirect URI and Hosted Link settings match the Railway deployment and are allowlisted in Plaid.
9. Configure a production webhook URL and handle Item errors / pending disconnect events before broad public launch.
10. Replace Sandbox credentials with Production credentials only after Plaid approval, and keep secrets only in Railway environment variables.
11. Verify Play Store Data Safety disclosures match the final connected-banking behavior.

Do not request Auth, Identity, Income, Assets, Liabilities, Investments, or payment products unless Pay-Pilot actually adds a feature that needs them.

---

## TERMS_OF_SERVICE_DRAFT.md

# Pay-Pilot Terms of Service — Production Draft

**Last updated:** September 13, 2026

Pay-Pilot is a personal budgeting and financial-management tool. It does not hold or move money, provide banking services, or provide professional financial, investment, tax, or legal advice.

Connected financial information can be delayed, incomplete, or temporarily unavailable. Users remain responsible for verifying balances, transactions, due dates, and payments with their financial institutions before making financial decisions.

If you connect an account, you authorize Pay-Pilot and Plaid to access the data scopes presented during Plaid Link for the features you request. You may revoke access by disconnecting an institution in Pay-Pilot, through your financial institution where supported, or through Plaid Portal.

Pay-Pilot may change as features are improved. Material changes affecting connected financial data should be reflected in the Privacy Policy and consent disclosures before release.

**Required before public launch:** add a real support contact and public Terms URL.

---

## UPLOAD-ME-TO-GITHUB.txt

PAY-PILOT OFFICIAL REPOSITORY — STARTING VERSION 8.0.0

For a full fresh repository:
Upload the contents of Pay-Pilot-main-built.zip to the Pay-Pilot repository.

For future update ZIPs:
Use the exact filename Pay-Pilot_update.zip.

Workflow:
Apply Pay-Pilot Update → Build Pay-Pilot Release → download Pay-Pilot-<version> signed APK.

Existing signing secrets stay named:
MYBILLS_KEYSTORE_HEX
MYBILLS_KEYSTORE_PASSWORD

They are intentionally preserved so the signing identity does not change.
