# Pay-Pilot 9.4.1 connectivity repair

- Adds a bank-service health check before Plaid starts.
- Gives a clear backend deployment message instead of the generic browser “Failed to fetch”.
- Adds a 15-second API timeout so the UI cannot hang indefinitely.
- Keeps Hosted Link as the Android bank-link flow.
- Resets the Backup & App panel scroll position and adds correct top spacing so the first section is not hidden under the header.
- Keeps the app version at 9.4.1 while this connection is being validated end-to-end.
