# Pay-Pilot 9.4.1 — backend deployment required

The Android APK and the Railway backend are two separate pieces. Plaid Hosted Link cannot complete correctly until the updated `backend/server.js` in this package is deployed to the Pay-Pilot Railway service.

What changed on the backend:
- Hosted Link tokens are still created with `paypilot://plaid-complete`.
- `/api/plaid/hosted-status/:userId` now reads Plaid Hosted Link results from `link_sessions[].results.item_add_results` (the current Plaid response shape).
- Successful public tokens are exchanged and stored before accounts are synced.
- `/api/health` reports the backend version; 9.4.1 should report `version: 9.4.1`.

After deployment, opening the backend root URL should return JSON that includes:
`"version":"9.4.1"` and `"hostedLink":true`.

Plaid Dashboard requirement:
- Hosted Link itself does not require registering the custom completion URI.
- The app package is `com.paypilot.app`.

Do not place the Plaid secret in the Android app. Keep `PLAID_CLIENT_ID` and `PLAID_SECRET` only in Railway environment variables.
