# Pay-Pilot Authoritative Finance Rules

**Authority version:** 9.5.3
**Purpose:** This file is the single source of truth for Pay-Pilot finance math and behavior. New frontend/backend work must follow these rules rather than adding competing finance calculations.

## 1. Connected accounts
- Deduplicate connected accounts by Plaid `account_id` (fallback to the app account ID only when needed).
- An account may be counted only once, even if a provider refresh returns duplicate rows.
- Checking/cash-management accounts may contribute to **Available Now** when the user includes them.
- Savings, money-market, and CD accounts do **not** contribute to Available Now by default.
- Credit/loan accounts never contribute positive money to Available Now.
- Account include/exclude choices are persistent and independent per account.

## 2. Available Now
`Available Now = included spendable bank balances + spendable cash on hand`

The Home gauge, Connected Accounts, Savings & Cash, and all other screens must read the same canonical value. No screen may independently re-sum the raw Plaid response.

## 3. Savings
`Total Savings = unique connected savings/money-market/CD balances + cash saved aside`

- Each connected savings account is counted once.
- Protected cash saved aside is included in Savings.
- Spendable cash on hand is not Savings; it belongs in Available Now.
- Tapping Savings opens Savings & Cash and shows the account-level breakdown.

## 4. Cushion and Safe to Spend
`Safe to Spend = max(0, Available Now - Cushion)`

Savings is excluded unless a future explicit user setting intentionally opts savings into spending. The gauge number and needle must be rendered from the same Safe-to-Spend value and same scale calculation.

## 5. Monthly income
Monthly Income is **received income**, not all future scheduled income.
- Past months: count paycheck occurrences in that month.
- Current month: count paycheck occurrences whose pay date is today or earlier.
- Future months: count $0 received income until the pay dates occur.
- Deleted paycheck occurrences are excluded.
- Editing one occurrence must not change unrelated paycheck occurrences.

When bank-transaction payroll matching is available, a confirmed deposited paycheck may be used as stronger evidence of receipt without double-counting the scheduled paycheck.

## 6. Monthly working budget
`Working Monthly Budget = received paychecks this month + manually added funds/credits this month`

- Future scheduled checks do not increase the working budget.
- When today's paycheck becomes received, the budget updates automatically.
- Added Funds/credits increase the working budget once.
- Spending and paid bills reduce budget remaining; they do not reduce the budget's income base.

## 7. Tracked money activity
- The Monthly Budget screen shows a compact activity summary by default.
- Show the newest 3 entries initially.
- **Show all** expands the full list; **Collapse** returns to the compact view.
- Edit/Delete remain available when entries are visible.
- Funds/credits retain their positive-flow identity and spending retains negative-flow identity.

## 8. Multi-institution rule
Any number of authorized institutions may be connected. Institution totals are presentation groupings only; canonical math is account-based and deduplicated by account ID.

## 9. Backup naming
New backup downloads use `pay-pilot-backup.json`. Legacy MyBills backup files remain restorable for compatibility.

## 10. Change discipline
Before changing finance behavior, update this authority document first. Do not add another late-stage module with a competing definition of Available Now, Savings, Monthly Income, Working Budget, Cushion, or Safe to Spend.
