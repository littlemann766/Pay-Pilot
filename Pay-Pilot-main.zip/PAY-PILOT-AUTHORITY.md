# Pay-Pilot Authority — 9.5.4

This file is the authoritative behavior contract for Pay-Pilot.

## Money source of truth
- Connected Plaid accounts are deduplicated by Plaid `account_id`.
- Available Now = included checking/cash-management balances + spendable cash on hand.
- Savings and debt accounts never enter Available Now.
- Savings = unique connected savings/money-market/CD balances + cash saved aside.
- Safe to Spend = Available Now - Cushion.
- All Home gauge numbers, needle position, labels, and institution views come from the same snapshot.

## Gauge
- Main page is All Spendable and is the only view that subtracts Cushion.
- Swipe horizontally for each institution, then Cash. Institution views show that institution only and do not subtract Cushion again.
- Gauge scale is generated from the displayed value; labels and needle share the same max.

## Income and budget
- Monthly Income counts paycheck occurrences whose payday has arrived. Future scheduled checks do not count.
- Working Monthly Budget = received paychecks in the viewed month + manually added refunds/funds.

## Spending / transactions
- Paid bills and manual spending remain editable Pay-Pilot ledger entries.
- Bank transaction history syncs from connected accounts and is shown on Spending.
- Bank transactions are not subtracted again from Available Now because live bank balances already include them. Matching/reconciliation can link bank transactions to bills/manual entries without double counting.

## Backups
- New backups use `Pay-Pilot-backup.json`; legacy MyBills backups remain restorable.


## 9.5.5 gauge paging rules
- Gauge pages are All Spendable, then one page per institution, then Cash.
- Swipe, arrows, and page dots must all navigate the same page state.
- Plaid account identity is item_id + account_id so two institutions cannot collapse into one.
- The overall page is the only page that subtracts Cushion. Institution and Cash pages are breakdown views.
- One final renderer controls both the displayed value and the needle.
