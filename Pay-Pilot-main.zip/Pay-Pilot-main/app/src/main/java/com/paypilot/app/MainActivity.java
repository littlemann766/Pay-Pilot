package com.paypilot.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.KeyguardManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.CancellationSignal;
import android.os.SystemClock;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int SAVE_BACKUP_REQUEST = 1002;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1003;
    private static final int DEVICE_CREDENTIAL_REQUEST = 1005;
    private static final String SECURITY_PREFS = "mybills_security";
    private static final String SECURITY_ENABLED_KEY = "app_lock_enabled";
    private static final String SECURITY_LAST_UNLOCK_KEY = "pin_lock_last_unlock_ms";
    private static final long RELOCK_AFTER_MS = 15 * 60 * 1000L; // 15-minute grace period
    private static final int SAVE_TEXT_REQUEST = 1004;
    private static final int REQUEST_BASE = 41000;

    private WebView webView;
    private LinearLayout lockView;
    private boolean authenticatedForSession = false;
    private boolean authenticationInProgress = false;
    private boolean externalActivityInProgress = false;
    private long stoppedAtElapsed = 0L;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;
    private String pendingTextExport;
    private String pendingTextFilename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (isAppLockEnabled() && !isWithinUnlockGracePeriod()) {
            showLockedScreen();
            authenticateUser();
            return;
        }

        unlockAndCreateWebView();
    }

    private void unlockAndCreateWebView() {
        authenticatedForSession = true;
        if (isAppLockEnabled()) rememberSuccessfulUnlock();
        authenticationInProgress = false;

        webView = new WebView(this);
        setContentView(webView);

        WebView.setWebContentsDebuggingEnabled(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true); // IndexedDB is used by My Bills.
        settings.setAllowFileAccess(true);  // Required for file:///android_asset/.
        settings.setAllowContentAccess(true); // Required for user-selected backup files.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSaveFormData(false);
        settings.setSafeBrowsingEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(false);
        cookieManager.setAcceptThirdPartyCookies(webView, false);

        // The JavaScript bridge is exposed only to the bundled, trusted app page.
        // Any web link is handed to the device browser instead of loading inside
        // this WebView, preventing an external page from reaching AndroidBridge.
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            private boolean handleNavigation(Uri uri) {
                if (uri == null) return true;
                String target = uri.toString();
                if (target.startsWith("file:///android_asset/") || "about:blank".equals(target)) {
                    return false;
                }

                String scheme = uri.getScheme();
                if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this,
                                "Unable to open that link.", Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(request == null ? null : request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(url == null ? null : Uri.parse(url));
            }
        });

        webView.clearCache(true);
        webView.clearHistory();

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                        new String[]{"application/json", "text/json", "text/plain"});

                try {
                    externalActivityInProgress = true;
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this,
                            "Unable to open local files.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        // 20.0.148: the bundled asset is the only in-app UI source.
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_PERMISSION_REQUEST);
        }
    }

    private static Uri soundUri(String sound) {
        if ("silent".equals(sound)) return null;
        if ("alarm".equals(sound))
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if ("ringtone".equals(sound))
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    }

    private static String channelId(String sound, boolean vibrate) {
        return "my_bills_" + sound + "_" + (vibrate ? "vibrate" : "quiet");
    }

    private static void ensureChannel(Context context, String sound, boolean vibrate) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        String id = channelId(sound, vibrate);
        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.getNotificationChannel(id) != null) return;

        NotificationChannel channel = new NotificationChannel(
                id, "My Bills alerts", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("Bills and reminder notifications");
        channel.enableVibration(vibrate);
        if (vibrate) channel.setVibrationPattern(new long[]{0, 250, 150, 250});

        Uri uri = soundUri(sound);
        if (uri == null) channel.setSound(null, null);
        else channel.setSound(uri, null);

        nm.createNotificationChannel(channel);
    }

    public class AndroidBridge {

        @JavascriptInterface
        public boolean isAppLockEnabled() {
            return MainActivity.this.isAppLockEnabled();
        }

        @JavascriptInterface
        public void setAppLockEnabled(boolean enabled) {
            setAppLockEnabledNative(enabled);
            runOnUiThread(() -> Toast.makeText(
                    MainActivity.this,
                    enabled ? "PIN Lock enabled. Brief app switches stay unlocked for 15 minutes." : "PIN Lock disabled.",
                    Toast.LENGTH_SHORT
            ).show());
        }

        @JavascriptInterface
        public void lockNow() {
            runOnUiThread(() -> {
                authenticatedForSession = false;
                clearUnlockGracePeriod();
                showLockedScreen();
                authenticateUser();
            });
        }
        @JavascriptInterface
        public void saveBackup(final String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "my-bills-backup.json");

                try {
                    externalActivityInProgress = true;
            startActivityForResult(intent, SAVE_BACKUP_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this,
                            "Unable to choose a save location.", Toast.LENGTH_SHORT).show();
                }
            });
        }


        @JavascriptInterface
        public void saveTextFile(final String filename, final String text) {
            runOnUiThread(() -> {
                pendingTextExport = text;
                pendingTextFilename = (filename == null || filename.trim().isEmpty())
                        ? "MyBills_summary.txt" : filename;

                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, pendingTextFilename);

                try {
                    externalActivityInProgress = true;
            startActivityForResult(intent, SAVE_TEXT_REQUEST);
                } catch (Exception e) {
                    pendingTextExport = null;
                    pendingTextFilename = null;
                    Toast.makeText(MainActivity.this,
                            "Unable to choose a save location.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> requestNotificationPermissionIfNeeded());
        }

        @JavascriptInterface
        public void testNotification(final String json) {
            runOnUiThread(() -> {
                try {
                    requestNotificationPermissionIfNeeded();
                    JSONObject obj = new JSONObject(json);
                    String title = obj.optString("title", "My Bills test");
                    String text = obj.optString("text", "Notifications are working.");
                    String sound = obj.optString("sound", "default");
                    boolean vibrate = obj.optBoolean("vibrate", true);
                    showNotification(MainActivity.this, title, text, sound, vibrate);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Could not send test notification.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void scheduleNotifications(final String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject root = new JSONObject(json);
                    boolean billsEnabled = root.optBoolean("enabled", false);
                    boolean remindersEnabled = root.optBoolean("reminderEnabled", true);
                    String sound = root.optString("sound", "default");
                    boolean vibrate = root.optBoolean("vibrate", true);

                    cancelScheduledNotifications();
                    ensureChannel(MainActivity.this, sound, vibrate);

                    if (!billsEnabled && !remindersEnabled) return;

                    requestNotificationPermissionIfNeeded();

                    int daysBefore = Math.max(0, Math.min(31,
                            root.optInt("daysBefore", 3)));
                    String time = root.optString("time", "09:00");
                    int requestIndex = 0;

                    if (billsEnabled) {
                        JSONArray bills = root.optJSONArray("bills");
                        if (bills != null)
                            requestIndex = scheduleBillAlarms(
                                    bills, daysBefore, time, sound, vibrate, requestIndex);
                    }

                    if (remindersEnabled) {
                        JSONArray reminders = root.optJSONArray("reminders");
                        if (reminders != null)
                            scheduleReminderAlarms(
                                    reminders, sound, vibrate, requestIndex);
                    }

                    Toast.makeText(MainActivity.this,
                            "Notifications updated.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this,
                            "Could not schedule notifications.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void cancelScheduledNotifications() {
        AlarmManager alarmManager =
                (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        for (int i = 0; i < 1200; i++) {
            Intent intent = new Intent(this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                    this, REQUEST_BASE + i, intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                alarmManager.cancel(pi);
                pi.cancel();
            }
        }
    }

    private void scheduleAlarm(long whenMillis, int requestCode,
                               String title, String text,
                               String sound, boolean vibrate) {
        if (whenMillis <= System.currentTimeMillis()) return;

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("text", text);
        intent.putExtra("sound", sound);
        intent.putExtra("vibrate", vibrate);

        PendingIntent pi = PendingIntent.getBroadcast(
                this, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager =
                (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, whenMillis, pi);
    }

    private int scheduleBillAlarms(JSONArray bills, int daysBefore, String time,
                                   String sound, boolean vibrate,
                                   int requestIndex) throws Exception {

        String[] hm = time.split(":");
        int hour = Integer.parseInt(hm[0]);
        int minute = hm.length > 1 ? Integer.parseInt(hm[1]) : 0;

        Calendar horizon = Calendar.getInstance();
        horizon.add(Calendar.MONTH, 12);
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

        for (int i = 0; i < bills.length() && requestIndex < 1000; i++) {
            JSONObject b = bills.getJSONObject(i);
            String name = b.optString("name", "Bill");
            double amount = b.optDouble("amount", 0);
            String due = b.optString("due", "");
            boolean recurring = b.optBoolean("recurring", false);
            String recurrence = b.optString("recurrence", "monthly");

            Date firstDate = df.parse(due);
            if (firstDate == null) continue;

            Calendar occurrence = Calendar.getInstance();
            occurrence.setTime(firstDate);

            while (occurrence.before(horizon) && requestIndex < 1000) {
                Calendar fire = (Calendar) occurrence.clone();
                fire.add(Calendar.DAY_OF_MONTH, -daysBefore);
                fire.set(Calendar.HOUR_OF_DAY, hour);
                fire.set(Calendar.MINUTE, minute);
                fire.set(Calendar.SECOND, 0);
                fire.set(Calendar.MILLISECOND, 0);

                if (fire.getTimeInMillis() > System.currentTimeMillis()) {
                    String text = name + " — $" +
                            String.format(Locale.US, "%.2f", amount) +
                            " due " + df.format(occurrence.getTime());

                    scheduleAlarm(
                            fire.getTimeInMillis(),
                            REQUEST_BASE + requestIndex,
                            name + " bill reminder",
                            text, sound, vibrate);
                    requestIndex++;
                }

                if (!recurring) break;
                if ("weekly".equals(recurrence))
                    occurrence.add(Calendar.DAY_OF_MONTH, 7);
                else if ("biweekly".equals(recurrence))
                    occurrence.add(Calendar.DAY_OF_MONTH, 14);
                else
                    occurrence.add(Calendar.MONTH, 1);
            }
        }
        return requestIndex;
    }

    private int scheduleReminderAlarms(JSONArray reminders,
                                       String sound, boolean vibrate,
                                       int requestIndex) throws Exception {
        SimpleDateFormat df =
                new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

        for (int i = 0; i < reminders.length() && requestIndex < 1100; i++) {
            JSONObject r = reminders.getJSONObject(i);
            String name = r.optString("name", "Reminder");
            String date = r.optString("date", "");
            String time = r.optString("time", "09:00");
            String notes = r.optString("notes", "");

            Date fire = df.parse(date + " " + time);
            if (fire == null || fire.getTime() <= System.currentTimeMillis())
                continue;

            String text = notes.trim().isEmpty() ? name : notes;
            scheduleAlarm(
                    fire.getTime(),
                    REQUEST_BASE + requestIndex,
                    name, text, sound, vibrate);
            requestIndex++;
        }
        return requestIndex;
    }

    public static class ReminderReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            String title = intent.getStringExtra("title");
            String text = intent.getStringExtra("text");
            String sound = intent.getStringExtra("sound");
            boolean vibrate = intent.getBooleanExtra("vibrate", true);

            if (sound == null) sound = "default";
            ensureChannel(context, sound, vibrate);
            showNotification(context,
                    title != null ? title : "My Bills",
                    text != null ? text : "You have an upcoming reminder.",
                    sound, vibrate);
        }
    }

    private static void showNotification(Context context,
                                         String title, String text,
                                         String sound, boolean vibrate) {
        NotificationManager nm =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        String channel = channelId(sound, vibrate);
        ensureChannel(context, sound, vibrate);

        Intent launch = context.getPackageManager()
                .getLaunchIntentForPackage(context.getPackageName());
        PendingIntent contentIntent = null;
        if (launch != null) {
            contentIntent = PendingIntent.getActivity(
                    context, 0, launch,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }

        Notification.Builder builder =
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? new Notification.Builder(context, channel)
                        : new Notification.Builder(context);

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true);

        if (contentIntent != null) builder.setContentIntent(contentIntent);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Uri uri = soundUri(sound);
            if (uri != null) builder.setSound(uri);
            if (vibrate) builder.setVibrate(new long[]{0, 250, 150, 250});
        }

        if (Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED) {
            nm.notify((int)(System.currentTimeMillis() & 0x7fffffff), builder.build());
        }
    }


    private boolean isAppLockEnabled() {
        SharedPreferences prefs = getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE);
        return prefs.getBoolean(SECURITY_ENABLED_KEY, false);
    }

    private boolean isWithinUnlockGracePeriod() {
        if (!isAppLockEnabled()) return true;
        long last = getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE)
                .getLong(SECURITY_LAST_UNLOCK_KEY, 0L);
        return last > 0L && (System.currentTimeMillis() - last) < RELOCK_AFTER_MS;
    }

    private void rememberSuccessfulUnlock() {
        getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE)
                .edit().putLong(SECURITY_LAST_UNLOCK_KEY, System.currentTimeMillis()).apply();
    }

    private void clearUnlockGracePeriod() {
        getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE)
                .edit().remove(SECURITY_LAST_UNLOCK_KEY).apply();
    }

    private void setAppLockEnabledNative(boolean enabled) {
        getSharedPreferences(SECURITY_PREFS, MODE_PRIVATE)
                .edit()
                .putBoolean(SECURITY_ENABLED_KEY, enabled)
                .remove(SECURITY_LAST_UNLOCK_KEY)
                .apply();
    }

    private boolean isDeviceSecure() {
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return km.isDeviceSecure();
        }
        return km.isKeyguardSecure();
    }

    private void showLockedScreen() {
        lockView = new LinearLayout(this);
        lockView.setOrientation(LinearLayout.VERTICAL);
        lockView.setGravity(Gravity.CENTER);
        lockView.setPadding(48, 48, 48, 48);
        lockView.setBackgroundColor(Color.rgb(7, 24, 51));

        TextView icon = new TextView(this);
        icon.setText("🔒");
        icon.setTextSize(44);
        icon.setGravity(Gravity.CENTER);

        TextView title = new TextView(this);
        title.setText("My Bills Locked");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 18, 0, 8);

        TextView sub = new TextView(this);
        sub.setText("Authenticate to view your financial information.");
        sub.setTextColor(Color.rgb(197, 209, 226));
        sub.setTextSize(15);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 26);

        Button unlock = new Button(this);
        unlock.setText("Unlock My Bills");
        unlock.setOnClickListener(v -> authenticateUser());

        lockView.addView(icon);
        lockView.addView(title);
        lockView.addView(sub);
        lockView.addView(unlock);

        setContentView(lockView);
    }

    private void authenticateUser() {
        if (authenticationInProgress) return;

        if (!isAppLockEnabled()) {
            unlockAndCreateWebView();
            return;
        }

        if (!isDeviceSecure()) {
            Toast.makeText(
                    this,
                    "Set up a PIN, pattern, password, or fingerprint in Android first. PIN Lock stayed off for this session.",
                    Toast.LENGTH_LONG
            ).show();
            unlockAndCreateWebView();
            return;
        }

        authenticationInProgress = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            showBiometricPrompt();
        } else {
            showDeviceCredentialPrompt();
        }
    }

    private void showBiometricPrompt() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            authenticationInProgress = false;
            showDeviceCredentialPrompt();
            return;
        }

        FingerprintManager fingerprintManager =
                (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);

        if (fingerprintManager == null
                || !fingerprintManager.isHardwareDetected()
                || !fingerprintManager.hasEnrolledFingerprints()) {
            authenticationInProgress = false;
            showDeviceCredentialPrompt();
            return;
        }

        CancellationSignal cancellationSignal = new CancellationSignal();

        fingerprintManager.authenticate(
                null,
                cancellationSignal,
                0,
                new FingerprintManager.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(
                            FingerprintManager.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        authenticationInProgress = false;
                        unlockAndCreateWebView();
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        Toast.makeText(
                                MainActivity.this,
                                "Fingerprint not recognized. Try again.",
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                    @Override
                    public void onAuthenticationError(
                            int errorCode,
                            CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        authenticationInProgress = false;
                        showDeviceCredentialPrompt();
                    }
                },
                null
        );
    }

    private void showDeviceCredentialPrompt() {
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (km == null) {
            authenticationInProgress = false;
            return;
        }

        Intent intent = km.createConfirmDeviceCredentialIntent(
                "Unlock My Bills",
                "Confirm your phone security to continue."
        );

        if (intent == null) {
            authenticationInProgress = false;
            Toast.makeText(this, "Device security is unavailable.", Toast.LENGTH_SHORT).show();
            return;
        }

        externalActivityInProgress = true;
        startActivityForResult(intent, DEVICE_CREDENTIAL_REQUEST);
    }

    private void relockIfNeeded() {
        if (!isAppLockEnabled() || !authenticatedForSession || authenticationInProgress) return;

        long awayFor = stoppedAtElapsed > 0L
                ? SystemClock.elapsedRealtime() - stoppedAtElapsed
                : 0L;

        if (awayFor >= RELOCK_AFTER_MS) {
            authenticatedForSession = false;
            stoppedAtElapsed = 0L;
            if (webView != null) {
                webView.setVisibility(View.INVISIBLE);
            }
            showLockedScreen();
            authenticateUser();
        } else {
            // Quick app switches stay unlocked and refresh the grace window.
            stoppedAtElapsed = 0L;
            rememberSuccessfulUnlock();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!externalActivityInProgress) {
            relockIfNeeded();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!externalActivityInProgress && authenticatedForSession) {
            stoppedAtElapsed = SystemClock.elapsedRealtime();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == DEVICE_CREDENTIAL_REQUEST) {
            externalActivityInProgress = false;
            authenticationInProgress = false;
            if (resultCode == RESULT_OK) {
                unlockAndCreateWebView();
            } else {
                showLockedScreen();
                Toast.makeText(this, "My Bills is still locked.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        externalActivityInProgress = false;

        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }


        if (requestCode == SAVE_TEXT_REQUEST) {
            if (resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null
                    && pendingTextExport != null) {
                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) {
                        out.write(pendingTextExport.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this,
                                "My Bills summary saved.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this,
                            "Could not save summary.", Toast.LENGTH_SHORT).show();
                }
            }
            pendingTextExport = null;
            pendingTextFilename = null;
            return;
        }

        if (requestCode == SAVE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null
                    && pendingBackupJson != null) {

                Uri uri = data.getData();
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out != null) {
                        out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        Toast.makeText(this,
                                "My Bills backup saved.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this,
                            "Could not save backup.", Toast.LENGTH_SHORT).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        // My Bills is a single-page WebView app. Android's Back button should
        // close the currently open in-app menu/dialog instead of finishing
        // the Activity and closing the whole app.
        if (webView == null) return;

        final String closeCurrentUi =
                "(function(){" +
                "try{" +
                "if(window.myBillsHandleAndroidBack&&window.myBillsHandleAndroidBack())return 'closed';" +
                // Prefer the dialog containing current focus (normally the top-most one).
                "var a=document.activeElement;" +
                "var d=(a&&a.closest)?a.closest('dialog[open]'):null;" +
                "if(!d){var ds=document.querySelectorAll('dialog[open]');if(ds.length)d=ds[ds.length-1];}" +
                "if(d){try{d.close();}catch(e){d.removeAttribute('open');}return 'closed';}" +
                // Also support HTML popovers if any are added later.
                "var ps=document.querySelectorAll('[popover]');" +
                "for(var i=ps.length-1;i>=0;i--){try{if(ps[i].matches(':popover-open')){ps[i].hidePopover();return 'closed';}}catch(e){}}" +
                "return 'none';" +
                "}catch(e){return 'none';}" +
                "})()";

        webView.evaluateJavascript(closeCurrentUi, result -> {
            if ("\"closed\"".equals(result)) return;

            // If a real WebView history entry exists, go back within the app.
            if (webView.canGoBack()) {
                webView.goBack();
                return;
            }

            // At a main tab/root screen, Back intentionally does nothing.
            // This prevents an accidental press from closing My Bills.
        });
    }
}
