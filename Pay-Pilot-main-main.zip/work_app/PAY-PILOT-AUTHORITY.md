# Pay-Pilot Foundation Authority

Version: 9.6.2

This build is the foundation for future Pay-Pilot work. New changes must extend this behavior instead of replacing it with older UI fragments or duplicate logic.

## Foundation rules

- `Pay-Pilot-main.zip` is the canonical GitHub source package.
- Keep the existing Android application id/signing path so upgrades install over prior versions.
- Do not change the Railway/Plaid backend unless a banking API change truly requires it.
- Android Back closes the top-most menu/dialog first and returns to Home only when no menu is open.
- Home gauge is the authoritative money summary.
- The gauge header shows `Pay-Pilot Gauge` and the active view/institution name.
- Gauge dots are prominent and appear only when there is more than one gauge page.
- Extra gauge pages exist only for connected institutions with spendable included accounts and/or cash when cash exists.
- Savings accounts are protected by default and are not included in Available Now unless explicitly changed by the user.
- The Savings metric must remain readable and clickable.
- Advanced money details are Advanced-mode only, collapsed by default, and user-toggleable.
- The mini Cash Gauge appears only when cash exists and shows spendable cash, protected cash, total cash, and a compact dial.
- Monthly Income reflects checks received so far in the viewed month.
- Budget uses received income plus added funds/refunds as the working amount.
- Home budget-used / budget-left summary opens Monthly Budget & Limits.
- Budget menu buttons must always open their corresponding tools.
- `Monthly Budget & Limits` opens the budget editor.
- `Paycheck Planner` opens the paycheck planner and gives a useful empty state if no schedule exists.
- `+ Add Spending` opens the spending/budget entry flow and focuses the description field.
- No visible button may be decorative or dead.
- Avoid duplicate renderers for the same feature. New fixes should update the authoritative surface instead of layering competing UI.
